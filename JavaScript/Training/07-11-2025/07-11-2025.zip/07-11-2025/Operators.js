console.log('Comparison Operator')
var a=10
var b="5"
console.log(a<b)
console.log(a>b)


var c=10
var d=10
console.log(c>=d)
console.log(c<=d)
let a1="5"
let a2=5
console.log("Loose Equality:")
console.log(a1==a2)
console.log("strict Equality:")
console.log(a1===a2)
console.log(a1!=a2)
console.log(a1!==a2)




console.log('Logical Operators:')
let b1=15
let b2=10
if(b1>b2 && b1<b2){
    console.log(true)
}
else{
    console.log(false)
}
if(b1>b2 || b1<b2){
    console.log(true)
}
else{
    console.log(false)
}

console.log('Bitwise Operators:')
var m1=12
var m2=10
console.log('Bitwise And operator')
console.log(m1&m2)
console.log('Bitwise OR Operator:')
console.log(a|b)
console.log('Bitwise XOR :')
console.log(m1^m2)
console.log('Left shift Operator:')
console.log(m1<<1)
console.log('Right Shift')
console.log(m1>>1)
console.log('String Operator:')
var n="Prashanth" +" " +"Don"
console.log(n)

console.log('Comma Operator:')
let x=(1,2,3,4,5,6)
console.log(x)
console.log('Tyeof Operator')
console.log(typeof true)
console.log(typeof 123)
console.log(typeof [1,2,3 ])
console.log('Ternary Operator')
let m4=10
let m6=5
m4>5?console.log(true):console.log(false)
console.log(5>10)
console.log(45<90)
console.log(12>10)
console.log(32>10)
76