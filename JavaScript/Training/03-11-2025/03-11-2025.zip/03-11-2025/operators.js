console.log('Arithematic Operators')
let a=10
let b=20
console.log(a+b)
console.log(a-b)
console.log(a*b)
console.log(a%b)
console.log(a/b)
console.log(++a - ++b)
console.log(--a + ++b)

console.log('Assignment operator:')
let c=5
let d=10
console.log(d+=c)
console.log(d-=c)
console.log(d**=c)
console.log(d+=c)
console.log(d**=c)


console.log('Relational Operator:')
let car=12
let bus=10
console.log(car>bus)
console.log(car<bus)
console.log(car!=bus)
console.log(car===bus)
console.log(car==bus)


console.log('Logical Operator:')
let m1=10
let m2=12
if(m1>12 && m1==m2){
    console.log(true)
}
else{
    console.log(false)
}
console.log('Ternary Operator:')
m1<m2?console.log(true):console.log(false)
