console.log(`single value in single memory`)
console.log(`1.String:Collection of characters`)
var a=`prashanth`
console.log(a)
var c=a
console.log(c)

// 2.Number:
console.log(`2.Number:`)
let num=10
console.log(num)
console.log(num)


// 3.Boolean
var PrashanthKodekandla=true
console.log(PrashanthKodekandla)
var Sai=false
console.log(Sai)



// 4.Undefined
let g
console.log(g)



// 5.Null
var car=null
console.log(car)


// function A(){
//     let a=[1,2]
//     let b=[1,2]
//     console.log(a==b)
//     console.log(a===b)
// }
// A()