console.log('Operators:')
console.log("Combined with varaibles and to a functionality")
console.log('Arithematic Operator:')
// +,-,*,/,%,++,--,
let a=10
let b=15
console.log(a+b)
console.log(a-b)
console.log(a*b)
console.log(a/b)
console.log(a%b)
console.log(a++)
console.log(++a)
console.log(--a + ++b)






console.log('Assigment Operator:')
let c=10
let d=5
d+=c
console.log(d)
d**=c

console.log(d)

