console.log(`Conditional Statements:`)
let a=10
let b=50
if(a>b){
    console.log(true)
}
else{
    console.log(false)
}
let age=25
if(age>18){
    console.log('Apply for voter card:')
}
else{
    console.log('Not Eligible')
}

let finance=1000
if(finance<1000){
    console.log(true)
}
else{
    console.log(false)
}
console.log('else if')

var apple='sweet'
if(apple=='hot'){
    console.log('hot')

}
else if(apple='sweet'){
    console.log('sweet')
}
else{
    console.log(false)
}
var bank='State Bank Of India'
if(bank=='State Bank Of India'){
    console.log('State Bank Of India:')
}
else if(bank=='Andra bank'){
    console.log('Andhra Bank')
}
else{
    console.log('false')
}

let Country='India'
if(Country=="India"){
    console.log('India')
}
else{
    console.log('Other Country')
}

var mobile='iphone'
var cost=70000
if(mobile=='iphone'&& cost==70000){
    console.log('iphone')
}
else{
    console.log('false')
}
console.log('switch:')
var animal='Lion'
switch(animal){
    case 'elephant':
        console.log('Elephant')
        break
        case 'Lion':
            console.log('Lion')
            break
            case 'Rabbit':
                console.log('Rabbit:')
}


