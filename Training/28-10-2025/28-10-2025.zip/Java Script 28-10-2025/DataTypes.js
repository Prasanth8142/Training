console.log('Data Types ')
// Data:to store the data for future
// 1.Primitive Data Types:single value in single memory
// 1.Reference Data Types:multiple values in single memory
// Primitive data Type:
// 1.String
// 2.Number
// 3.Boolean
// 4.bigInt
// 5.undefined
// 6.Null
// variables:
// let,var,const
// 1.String:Collection Of Characters
var name='Prashanth'
var secondname='Don'
console.log(name+secondname)

var b1="madhu"
var b2="sai"
console.log(b1+b2)




var m1='shilpa'
var m2='don'
console.log(m1+m2)

// 2.Number:Represents both integers &Floating point numbers
let num1=8142
let num2=225321
console.log(num1+num2)
  
let v1=123.567
let v2=0.456
console.log(v1)
console.log(v2)


let n1=567.45
let b3=64.56
console.log(n1-b3)
// 3.Boolean:Represents of logical values 
var a=true
var b=false
console.log(a)
console.log(b)



// 4.bigInt:used to very large integers
let c=3326367675674517645
let d=7647746473648746278
console.log(c+d)




// 5.Undefined: a varible declared but not assigned value
var f=
console.log(f)

var h=
console.log(h)
// 6.NULL:Absence of value:
 var g=null
 console.log(g)

 let v3=null
 console.log(v3)


