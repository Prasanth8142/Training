console.log('Operators')

console.log('Operators:Combination with variables to a functionality')
console.log('1.Arithematic operator: +,-,*,/,%,++,--')
let a=10
let b=20
let c=a+b
console.log(c)
let d=a-b
console.log(a-b)
let e=a*b
console.log(e)
let f=a/b
console.log(f)
let g=a++
console.log(g)
let h=++a
console.log(h)
console.log(++a + --b)
console.log(a%b)
console.log(d+a)
console.log(e+g)
console.log(--g)
console.log(--h)
console.log(++h -a++)







console.log('2.Assignment operator')
let a1=10
let a2=20
console.log(a1)
console.log(a1-=a2)
console.log(a2-=a1)
console.log(a1+=a2)
console.log(a1*=a2)
let m1=10
let m2=20
let m3=m1
let m4=m2
console.log(m1)
console.log(m2)
console.log(m3)
console.log(m4)
let m5=m1*=m2
console.log(m5)
let m6=m1-=m2
console.log(m6)
let m7=m1+=m2
console.log(m7)






console.log('3.comparison operator')
if(a==b){
    console.log('true')
}
else{
    console.log('false')
}
var c1=a
console.log(c1)
let a4=c1
console.log(a4)
if(a>b){
    console.log(true)
}
else{
    console.log(false)
}

if(a<=b){
    console.log(true)
}
else{
    console.log(false)
}


console.log('4.logical operator:')
// &&,||
if(a=b && a===b){
    console.log(true)
}
else
{
    console.log(false)
}
if(a!=b ||a==b){
    console.log(true)
}
else{
    console.log(false)
}




console.log('ternary operator')
let v1=10
let v2=10
a=b?console.log(true):console.log(false)